import 'dotenv/config';
import * as exercisesModel from './exercises_model.mjs';
import express from 'express';
import asyncHandler from 'express-async-handler';

const app = express();
app.use(express.json())

const PORT = process.env.PORT;

function validateRequestBody(body) {
    const allowedProperties = ['name', 'reps', 'weight', 'unit', 'date'];

    // Ensure only the 5 required properties are present
    const bodyKeys = Object.keys(body);
    if (bodyKeys.length !== allowedProperties.length || !bodyKeys.every(key => allowedProperties.includes(key))) {
        return false;
    }

    // Validate individual properties
    const { name, reps, weight, unit, date } = body;

    if (typeof name !== 'string' || name.trim().length === 0) {
        return false;
    }
    if (!Number.isInteger(reps) || reps <= 0) {
        return false;
    }
    if (!Number.isInteger(weight) || weight <= 0) {
        return false;
    }
    if (unit !== 'kgs' && unit !== 'lbs') {
        return false;
    }
    const dateRegex = /^\d{2}-\d{2}-\d{2}$/;
    if (!dateRegex.test(date)) {
        return false;
    }

    return true;
}

app.listen(PORT, async () => {
    await exercisesModel.connect(false)
    console.log(`Server listening on port ${PORT}...`);
});

/**
 * Create a new exercise with the name, reps, weight, unit, and date provided in the body.
 */

app.post('/exercises', asyncHandler(async (req, res) => {
    const isValid = validateRequestBody(req.body);

    if (!isValid) {
        return res.status(400).json({ Error: 'Invalid request' });
    }

    const {name, reps, weight, unit, date} = req.body;

    const newExercise = await exercisesModel.createExercise(name, reps, weight, unit, date);
    res.status(201).json(newExercise);

}));

app.get('/exercises', asyncHandler(async (req, res) => {

    const exercises = await exercisesModel.getAllExercises();

    res.status(200).json(exercises);
}));

app.get('/exercises/:_id', asyncHandler(async (req, res) => {

    const {_id} = req.params;

    const ExerciseID = await exercisesModel.findExerciseID(_id)


    if (ExerciseID){
        return res.status(200).json(ExerciseID);
    }

    res.status(404).json({"Error": "Not found"});

}));

app.put('/exercises/:_id', asyncHandler(async (req, res) => {

    const {_id} = req.params;
    const isValid = validateRequestBody(req.body);
    const toUpdate = req.body;

    if (!isValid) {
        return res.status(400).json({Error: 'Invalid request'})
    } 

    const updatedExercise = await exercisesModel.updateExercise(_id, toUpdate);

    if(!updatedExercise){
        return res.status(404).json({"Error": "Not found"});
    }

    res.status(200).json(updatedExercise);
}));

app.delete('/exercises/:_id', asyncHandler(async (req, res) => {

    const {_id} = req.params;
    const ExerciseID = await exercisesModel.findExerciseID(_id)


    if (!ExerciseID){
        return res.status(404).json({"Error": "Not found"});
    }
    
    const deleted = await exercisesModel.deleteExerciseByID(_id);

    res.status(204).send();
}));



