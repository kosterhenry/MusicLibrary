import mongoose from 'mongoose';
import 'dotenv/config';

const EXERCISE_DB_NAME = 'exercise_db';
const EXERCISE_COLLECTION = 'exercises';
const EXERCISE_CLASS = 'Exercise';

let connection = undefined;
let Exercise = undefined;

/**
 * This function connects to the MongoDB server.
 */
async function connect(){
    try{
        await mongoose.connect(process.env.MONGODB_CONNECT_STRING, {dbName: EXERCISE_DB_NAME});
        connection = mongoose.connection;
        console.log("Successfully connected to MongoDB using Mongoose!");
        Exercise = createModel();
    } catch(err){
        console.log(err);
        throw Error(`Could not connect to MongoDB ${err.message}`)
    }
}

function createModel(){
    const exerciseSchema = mongoose.Schema({
        name: {type: String, required: true},
        reps: {type: Number, required: true, 
            validate: {
                validator: Number.isInteger,
                message: 'Reps must be an integer.',
            },
            min: [1, 'Reps must be greater than 0.'],
        },
        weight: {type: Number, required: true, 
            validate: {
                validator: Number.isInteger,
                message: 'Weight must be an integer.',
            },
            min: [1, 'Weight must be greater than 0.'],
        },
        unit: {type: String, required: true, 
            enum: {
                values: ['kgs', 'lbs'],
                message: 'Unit must be either "kgs" or "lbs".',
            },
        },
        date: {type: String, required: true, 
            validate: {
                validator: function (value) {
                    // Validate MM-DD-YY format
                    return /^\d{2}-\d{2}-\d{2}$/.test(value);
                },
                message: 'Date must be in MM-DD-YY format.',
            },
        },

    });
    return mongoose.model(EXERCISE_CLASS, exerciseSchema);
}

/**
 * Create an exercise
 * @param {string} name
 * @param {Number} reps
 * @param {Number} weight
 * @param {string} unit
 * @param {string} date
 * @returns
 */

async function createExercise(name, reps, weight, unit, date){
    try{
        const newExercise = new Exercise({name: name, reps: reps, weight: weight, unit: unit, date: date});
        return newExercise.save();
    } catch (err) {
        console.error("error saving exercise:", err);
        throw err;
    }
}

async function getAllExercises(){
    return await Exercise.find({});
}

async function findExerciseID(_id){

    const query = Exercise.findById(_id);
    return query.exec();
}

async function updateExercise(_id, toUpdate){
    const result = await Exercise.findByIdAndUpdate({_id: _id}, {$set: toUpdate});
    return result
}

async function deleteExerciseByID(_id){
    const result = await Exercise.deleteOne({_id: _id});
    return result.deletedCount;
}



export { connect, createExercise, getAllExercises, findExerciseID, updateExercise, deleteExerciseByID };
